import 'package:flutter/material.dart';
import 'package:supabase/supabase.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:myapp/auth/auth_state.dart';

import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:myapp/src/pages/index.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:map/map.dart';
import 'package:latlng/latlng.dart';
import 'package:paged_vertical_calendar/paged_vertical_calendar.dart';

class PageHomePage extends StatefulWidget {
  const PageHomePage({
    Key? key,
    this.param1 = '6',
  }) : super(key: key);

  final String param1;

  @override
  _State createState() => _State();
}

class _State extends AuthState<PageHomePage>
    with SingleTickerProviderStateMixin {
  final datasets = <String, dynamic>{};

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: Container(
          margin: EdgeInsets.zero,
          padding: const EdgeInsets.only(
            left: 2,
            top: 2,
            right: 2,
            bottom: 2,
          ),
          width: double.maxFinite,
          height: 65,
          decoration: BoxDecoration(
            color: const Color(0xFFFA0505),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(8.5),
              topRight: Radius.circular(8.5),
              bottomRight: Radius.circular(8.5),
              bottomLeft: Radius.circular(8.5),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              GestureDetector(
                onTap: () async {
                  if (!Scaffold.of(context).isDrawerOpen) {
                    Scaffold.of(context).openDrawer();
                  }
                },
                child: Text('''Canlender''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: const Color(0xFF000000),
                        fontWeight: FontWeight.w500,
                        fontSize: 20,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    maxLines: 1),
              ),
            ],
          ),
        ),
      ),
      drawer: Drawer(
        child: Container(
          margin: EdgeInsets.zero,
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
            color: Color(0xFFFFFFFF),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  top: 20,
                  bottom: 20,
                ),
                child: Text('''Schedule ''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: const Color(0xFF000000),
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        fontStyle: FontStyle.italic,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    maxLines: 1),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  top: 20,
                  bottom: 20,
                ),
                child: Text('''Day''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: const Color(0xFF000000),
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    maxLines: 1),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  top: 20,
                  bottom: 20,
                ),
                child: Text('''3 Days''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: const Color(0xFF000000),
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        fontStyle: FontStyle.italic,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    maxLines: 1),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  top: 20,
                  bottom: 20,
                ),
                child: Text('''Month''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: const Color(0xFF000000),
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    maxLines: 1),
              ),
              Padding(
                padding: const EdgeInsets.only(
                  top: 20,
                  bottom: 20,
                ),
                child: Text('''Setting ''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: const Color(0xFF000000),
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        fontStyle: FontStyle.italic,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    maxLines: 1),
              ),
            ],
          ),
        ),
      ),
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            margin: EdgeInsets.zero,
            padding: EdgeInsets.zero,
            width: double.maxFinite,
            decoration: const BoxDecoration(
              color: Color(0xFFFFFFFF),
            ),
            child: Builder(
              builder: (context) {
                return PagedVerticalCalendar(
                  addAutomaticKeepAlives: true,
                  dayBuilder: (context, date) {
                    final dataset = datasets['null'];
                    final element = (dataset as List<dynamic> ?? <dynamic>[])
                        .firstWhereOrNull((e) => e['null']);
                    return Container(
                      margin: const EdgeInsets.only(
                        left: 8,
                        top: 8,
                        right: 8,
                        bottom: 8,
                      ),
                      padding: const EdgeInsets.only(
                        left: 3,
                        top: 3,
                        right: 3,
                        bottom: 3,
                      ),
                      decoration: element != null
                          ? const BoxDecoration()
                          : const BoxDecoration(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${date.day}',
                            style: GoogleFonts.balooDa(
                              textStyle: TextStyle(
                                color: const Color(0xFF000000),
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                                fontStyle: FontStyle.normal,
                                decoration: TextDecoration.none,
                              ),
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ],
                      ),
                    );
                  },
                  monthBuilder: (context, month, year) {
                    final monthValue =
                        DateFormat('MMMM').format(DateTime(0, month));
                    return SizedBox(
                      width: double.maxFinite,
                      child: Text(
                        '$monthValue',
                        style: GoogleFonts.balooDa(
                          textStyle: TextStyle(
                            color: const Color(0xFF000000),
                            fontWeight: FontWeight.w900,
                            fontSize: 18,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.left,
                      ),
                    );
                  },
                );
              },
            ),
          ),
          // BottomBar
          Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                margin: EdgeInsets.zero,
                padding: EdgeInsets.zero,
                width: double.maxFinite,
                height: 50,
                decoration: BoxDecoration(
                  color: const Color(0xFFFB0000),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(7.5),
                    topRight: Radius.circular(7.5),
                    bottomRight: Radius.circular(7.5),
                    bottomLeft: Radius.circular(7.5),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Icon(
                      MdiIcons.fromString('''account-box-multiple'''),
                      size: 40,
                      color: Color(0xFF060202),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 8,
                        top: 8,
                        right: 8,
                        bottom: 8,
                      ),
                      child: Icon(
                        MdiIcons.fromString('''alarm-check'''),
                        size: 40,
                        color: Color(0xFF060202),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}
